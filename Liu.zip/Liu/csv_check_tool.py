import os
from PIL import Image, ImageDraw
import csv

# 路径设置
dataset_dir = 'D:\\深度学习肺癌\\人工智能\\标记过45个结节'  # 数据集的根目录
output_dir = 'my_dataset/output/'  # 保存融合图像的目录

# 确保输出目录存在
os.makedirs(output_dir, exist_ok=True)

# 遍历目标路径下的所有文件夹
for folder_name in os.listdir(dataset_dir):
    folder_path = os.path.join(dataset_dir, folder_name)
    if os.path.isdir(folder_path):
        # 在输出目录下为当前文件夹创建一个同名的子目录
        output_folder_path = os.path.join(output_dir, folder_name)
        os.makedirs(output_folder_path, exist_ok=True)

        # 在每个文件夹内先遍历非副本的CSV文件
        for file in os.listdir(folder_path):
            file_path = os.path.join(folder_path, file)
            # 检查是否是CSV文件并且不是副本，且不以'._'为前缀
            if file.lower().endswith('.csv') and '副本' not in file and not file.startswith('._'):
                # 提取CSV文件名的前两段或全部作为图片文件名的前缀
                csv_parts = file.split('-')
                if len(csv_parts) == 3:
                    image_prefix = '-'.join(csv_parts[:2])
                elif len(csv_parts) == 2:
                    image_prefix = file.replace('.csv', '')
                else:
                    continue  # 如果不符合上述两种情况，则跳过当前CSV文件

                # 遍历文件夹中的所有图片文件，查找匹配的图片文件
                for image_file in os.listdir(folder_path):
                    if image_file.startswith(image_prefix) and image_file.lower().endswith(
                            ('.png', '.jpg', '.jpeg', '.bmp', '.gif')):
                        image_path = os.path.join(folder_path, image_file)
                        # 处理图片和csv文件
                        # 打开CSV文件并读取坐标
                        coords = []  # 存储所有坐标的列表
                        with open(file_path, 'r', encoding='utf-8') as csv_file:  # 设置编码为utf-8
                            reader = csv.DictReader(csv_file)
                            for row in reader:
                                x = int(row['X'])
                                y = int(row['Y'])
                                coords.append((x, y))

                        # 加载图像
                        image = Image.open(image_path).convert("RGBA")  # 确保图像是RGBA模式
                        image_width, image_height = image.size

                        # 创建一个透明的图层
                        overlay = Image.new('RGBA', (image_width, image_height), (255, 255, 255, 0))
                        draw = ImageDraw.Draw(overlay)

                        # 设置半透明的红色轮廓
                        transparent_red = (255, 0, 0, 55)  # R, G, B, A (48 is semi-transparent)

                        # 在透明图层上绘制轮廓
                        draw.polygon(coords, fill=None, outline=transparent_red)

                        # 将透明图层与原始图像合并
                        combined_image = Image.alpha_composite(image, overlay)

                        # 保存合并后的图像为PNG格式，以保持透明度信息
                        output_image_path = os.path.join(output_folder_path, image_file)
                        combined_image.save(output_image_path, 'PNG')  # 注意这里指定了格式为PNG
                        print(f"Saved annotated image to {output_image_path}")

                        break  # 找到匹配的图片文件后，跳出内层循环

print("All images processed.")

