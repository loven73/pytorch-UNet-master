import os

from argparse import ArgumentParser
#import unet
import torch

from unet.blocks import SoftDiceLoss
from unet.unet import UNet2D
from unet.model import Model
from unet.dataset import Image2D,ImageToImage2D

parser = ArgumentParser()
parser.add_argument('--dataset', required=True, type=str)
parser.add_argument('--results_path', required=True, type=str)
parser.add_argument('--model_path', required=True, type=str)
parser.add_argument('--device', default='cuda', type=str)
args = parser.parse_args()

#predict_dataset = Image2D(args.dataset)
predict_dataset = ImageToImage2D(args.dataset)
model = torch.load(args.model_path)

if not os.path.exists(args.results_path):
    os.makedirs(args.results_path)

# 假设您已经定义了 loss 和 optimizer
# loss = SoftDiceLoss()  # 使用您定义的 SoftDiceLoss
# optimizer = torch.optim.Adam(model.parameters())  # 使用 Adam 优化器
conv_depths = [32, 64, 128, 256, 512]
unet = UNet2D(3, 2, conv_depths)

model = Model(
    net=unet,  # 注意这里应该是 UNet2D 的一个实例，而不是类本身
    checkpoint_folder=args.results_path,
    device=args.device
)


#model_experiment = Model(net=UNet2D, checkpoint_folder=args.results_path, device=args.device)

model.predict_dataset(predict_dataset, args.results_path)